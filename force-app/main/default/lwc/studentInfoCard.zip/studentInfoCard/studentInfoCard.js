import { LightningElement, api } from 'lwc';

export default class StudentInfoCard extends LightningElement {
    @api studentId = '';
    _studentName = '';
    @api
    get studentName() {
        return this._studentName;
    }
    set studentName(value) {
        this._studentName = value ? String(value) : '';
    }

    @api grade = '';

    _subjects = [];
    @api
    get subjects() {
        return this._subjects;
    }
    set subjects(value) {
        if (Array.isArray(value)) {
            this._subjects = value;
        } else if (typeof value === 'string') {
            try {
                const parsed = JSON.parse(value);
                if (Array.isArray(parsed)) {
                    this._subjects = parsed;
                } else {
                    this._subjects = value.split(',').map(s => s.trim()).filter(Boolean);
                }
            } catch (e) {
                this._subjects = value.split(',').map(s => s.trim()).filter(Boolean);
            }
        } else {
            this._subjects = [];
        }
        this.totalSubjects = this._subjects.length;
    }

    @api isActive = false;
    @api displayMode = 'detailed';

    enrollmentDate = null;
    totalSubjects = 0;

    connectedCallback() {
        if (!this.enrollmentDate) {
            const d = new Date();
            this.enrollmentDate = d.toISOString().slice(0, 10);
        }
        this.totalSubjects = Array.isArray(this._subjects) ? this._subjects.length : 0;
    }

    get studentStatus() {
        return this.isActive ? 'Active' : 'Inactive';
    }

    get subjectsList() {
        return this._subjects.length ? this._subjects.join(', ') : 'No subjects';
    }

    get isCompact() {
        return this.displayMode === 'compact';
    }

    get hasSubjects() {
        return this._subjects && this._subjects.length > 0;
    }

    @api
    toggleActive() {
        this.isActive = !this.isActive;
    }

    // handler wired to the button in template
    handleToggleActive() {
        this.toggleActive();
        // emit an event so parent can react if wanted
        this.dispatchEvent(new CustomEvent('statuschange', {
            detail: { isActive: this.isActive, studentId: this.studentId }
        }));
    }
}
